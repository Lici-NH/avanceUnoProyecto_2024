/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.preyecto_alg;

import Interfaz.Login;
/**
 *
 * @author ALIS
 */
public class Preyecto_Alg {

    public static void main(String[] args) {
      Login login = new Login();  
      
      //Hacer visible la interfaz de login
      login.setVisible(true);
      login.setLocationRelativeTo(null);
      
    }
}
